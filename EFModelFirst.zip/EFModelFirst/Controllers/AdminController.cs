﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EFModelFirst.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        RahitechModel1Container context = new RahitechModel1Container();
        public ActionResult Index()
        {
            var emplist = context.Employees.ToList();
            return View(emplist);
        }
    }
}